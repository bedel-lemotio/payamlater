/// id : 1
/// name : "MOTOR BIKES"
/// descr : ""
/// Desable : 0
/// CreateBy : 11
/// UpdateBy : null
/// CreateDate,UpdateDate : "2023-05-30 10:52:10"

class Categories {
  Categories({
      num? id, 
      String? name, 
      String? descr, 
      num? desable, 
      num? createBy, 
      dynamic updateBy, 
      String? createDateUpdateDate,}){
    _id = id;
    _name = name;
    _descr = descr;
    _desable = desable;
    _createBy = createBy;
    _updateBy = updateBy;
    _createDateUpdateDate = createDateUpdateDate;
}

  Categories.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'];
    _descr = json['descr'];
    _desable = json['Desable'];
    _createBy = json['CreateBy'];
    _updateBy = json['UpdateBy'];
    _createDateUpdateDate = json['CreateDate,UpdateDate'];
  }
  num? _id;
  String? _name;
  String? _descr;
  num? _desable;
  num? _createBy;
  dynamic _updateBy;
  String? _createDateUpdateDate;
Categories copyWith({  num? id,
  String? name,
  String? descr,
  num? desable,
  num? createBy,
  dynamic updateBy,
  String? createDateUpdateDate,
}) => Categories(  id: id ?? _id,
  name: name ?? _name,
  descr: descr ?? _descr,
  desable: desable ?? _desable,
  createBy: createBy ?? _createBy,
  updateBy: updateBy ?? _updateBy,
  createDateUpdateDate: createDateUpdateDate ?? _createDateUpdateDate,
);
  num? get id => _id;
  String? get name => _name;
  String? get descr => _descr;
  num? get desable => _desable;
  num? get createBy => _createBy;
  dynamic get updateBy => _updateBy;
  String? get createDateUpdateDate => _createDateUpdateDate;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['name'] = _name;
    map['descr'] = _descr;
    map['Desable'] = _desable;
    map['CreateBy'] = _createBy;
    map['UpdateBy'] = _updateBy;
    map['CreateDate,UpdateDate'] = _createDateUpdateDate;
    return map;
  }

}